﻿namespace CpoDesign.Components.Settings.Interface
{
    public interface ISettings
    {
        string Get(string keyName);
    }
}
